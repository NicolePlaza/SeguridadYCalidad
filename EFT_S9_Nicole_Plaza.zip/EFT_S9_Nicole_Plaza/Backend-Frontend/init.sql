-- 1. Crear la base de datos
CREATE DATABASE IF NOT EXISTS mydatabase
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE mydatabase;

-- 2. Tabla de usuarios (autenticación backend)
CREATE TABLE IF NOT EXISTS user (
    id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255),
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- 3. Tabla de mascotas disponibles para adopción
CREATE TABLE IF NOT EXISTS pet (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    species VARCHAR(255),
    breed VARCHAR(255),
    age INT,
    gender VARCHAR(50),
    location VARCHAR(255),
    status VARCHAR(50) DEFAULT 'available',
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- 4. Tabla de fotos de mascotas (colección)
CREATE TABLE IF NOT EXISTS pet_photos (
    pet_id INT NOT NULL,
    photo_url VARCHAR(500),
    FOREIGN KEY (pet_id) REFERENCES pet(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Tabla de pacientes (dueños/adoptantes)
CREATE TABLE IF NOT EXISTS patient (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    species VARCHAR(255),
    breed VARCHAR(255),
    age INT,
    owner VARCHAR(255),
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- 6. Tabla de citas
CREATE TABLE IF NOT EXISTS appointment (
    id INT NOT NULL AUTO_INCREMENT,
    patient_id INT,
    date DATE,
    time TIME,
    reason VARCHAR(255),
    veterinarian VARCHAR(255),
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- 7. Tabla de facturas
CREATE TABLE IF NOT EXISTS invoice (
    id INT NOT NULL AUTO_INCREMENT,
    appointment_id INT,
    issue_date DATE,
    vat_rate DECIMAL(19,2),
    subtotal DECIMAL(19,2),
    vat_amount DECIMAL(19,2),
    total DECIMAL(19,2),
    notes VARCHAR(500),
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- 8. Tabla de ítems de factura
CREATE TABLE IF NOT EXISTS invoice_line_item (
    id INT NOT NULL AUTO_INCREMENT,
    invoice_id INT NOT NULL,
    type VARCHAR(50),
    description VARCHAR(255),
    quantity INT,
    unit_price DECIMAL(19,2),
    line_total DECIMAL(19,2),
    PRIMARY KEY (id),
    FOREIGN KEY (invoice_id) REFERENCES invoice(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- DATOS DE PRUEBA
-- ============================================================

-- Usuario de prueba (password: password123)
INSERT INTO user (id, username, email, password) VALUES
(1, 'admin', 'admin@unidos.cl', 'password123'),
(2, 'veterinario', 'vet@unidos.cl', 'password123');

-- Mascotas disponibles para adopción
INSERT INTO pet (id, name, species, breed, age, gender, location, status) VALUES
(1, 'Luna',    'Perro', 'Labrador',       3, 'Hembra', 'Santiago Centro', 'available'),
(2, 'Max',     'Perro', 'Pastor Aleman',  2, 'Macho',  'Providencia',     'available'),
(3, 'Michi',   'Gato',  'Siames',         1, 'Hembra', 'Las Condes',      'available'),
(4, 'Rocky',   'Perro', 'Bulldog Frances',4, 'Macho',  'Nunoa',           'available'),
(5, 'Pelusa',  'Gato',  'Persa',          5, 'Hembra', 'Maipu',           'adopted');

-- Fotos de mascotas
INSERT INTO pet_photos (pet_id, photo_url) VALUES
(1, 'https://placedog.net/500/300?id=1'),
(2, 'https://placedog.net/500/300?id=2'),
(3, 'https://placekitten.com/500/300'),
(4, 'https://placedog.net/500/300?id=4'),
(5, 'https://placekitten.com/500/301');

-- Pacientes (mascotas registradas con dueno)
INSERT INTO patient (id, name, species, breed, age, owner) VALUES
(1, 'Luna',   'Perro', 'Labrador',       3, 'Maria Gonzalez'),
(2, 'Michi',  'Gato',  'Siames',         1, 'Carlos Perez'),
(3, 'Rocky',  'Perro', 'Bulldog Frances', 4, 'Ana Lopez');

-- Citas veterinarias
INSERT INTO appointment (id, patient_id, date, time, reason, veterinarian) VALUES
(1, 1, '2026-05-10', '09:00:00', 'Control general',        'Dr. Fernandez'),
(2, 2, '2026-05-10', '10:30:00', 'Vacunacion',             'Dra. Munoz'),
(3, 3, '2026-05-11', '11:00:00', 'Revision post-adopcion', 'Dr. Fernandez');

-- Factura de ejemplo
INSERT INTO invoice (id, appointment_id, issue_date, vat_rate, subtotal, vat_amount, total, notes) VALUES
(1, 1, '2026-05-10', 0.19, 25000.00, 4750.00, 29750.00, 'Control general Luna');

INSERT INTO invoice_line_item (id, invoice_id, type, description, quantity, unit_price, line_total) VALUES
(1, 1, 'SERVICE',    'Consulta veterinaria', 1, 15000.00, 15000.00),
(2, 1, 'MEDICATION', 'Desparasitante',       1, 10000.00, 10000.00);

-- Ajustar auto_increment para evitar conflictos con Hibernate
ALTER TABLE user AUTO_INCREMENT = 100;
ALTER TABLE pet AUTO_INCREMENT = 100;
ALTER TABLE patient AUTO_INCREMENT = 100;
ALTER TABLE appointment AUTO_INCREMENT = 100;
ALTER TABLE invoice AUTO_INCREMENT = 100;
ALTER TABLE invoice_line_item AUTO_INCREMENT = 100;
