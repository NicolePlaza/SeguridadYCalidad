package com.duoc.backend;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @Test
    void registerUserShouldReturnCreatedWhenValid() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUsername("newuser");
        request.setEmail("new@test.com");
        request.setPassword("pass123");

        User savedUser = new User();
        savedUser.setId(1);
        savedUser.setUsername("newuser");
        savedUser.setEmail("new@test.com");

        when(userService.registerUser(any())).thenReturn(savedUser);

        ResponseEntity<?> response = userController.registerUser(request);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertInstanceOf(UserResponse.class, response.getBody());
        UserResponse body = (UserResponse) response.getBody();
        assertEquals(1, body.getId());
        assertEquals("newuser", body.getUsername());
        assertEquals("new@test.com", body.getEmail());
        verify(userService).registerUser(request);
    }

    @Test
    void registerUserShouldReturnBadRequestWhenUsernameExists() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUsername("existing");
        request.setEmail("new@test.com");
        request.setPassword("pass123");

        when(userService.registerUser(any())).thenThrow(new IllegalArgumentException("Username already exists"));

        ResponseEntity<?> response = userController.registerUser(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertInstanceOf(Map.class, response.getBody());
        @SuppressWarnings("unchecked")
        Map<String, String> error = (Map<String, String>) response.getBody();
        assertEquals("Username already exists", error.get("message"));
    }

    @Test
    void registerUserShouldReturnBadRequestWhenEmailExists() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUsername("newuser");
        request.setEmail("existing@test.com");
        request.setPassword("pass123");

        when(userService.registerUser(any())).thenThrow(new IllegalArgumentException("Email already exists"));

        ResponseEntity<?> response = userController.registerUser(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertInstanceOf(Map.class, response.getBody());
        @SuppressWarnings("unchecked")
        Map<String, String> error = (Map<String, String>) response.getBody();
        assertEquals("Email already exists", error.get("message"));
    }
}