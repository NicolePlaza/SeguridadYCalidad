package com.duoc.backend;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class BackendApplicationTests {

	@Test
	void mainClassShouldExist() {
		assertNotNull(BackendApplication.class);
	}

}