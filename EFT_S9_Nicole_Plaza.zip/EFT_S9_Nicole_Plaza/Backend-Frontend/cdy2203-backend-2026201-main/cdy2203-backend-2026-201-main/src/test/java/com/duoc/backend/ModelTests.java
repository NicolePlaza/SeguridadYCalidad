package com.duoc.backend;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ModelTests {

    // ── Appointment ──────────────────────────────────────────────────────────

    @Test
    void appointmentDefaultConstructorShouldCreateInstance() {
        Appointment appointment = new Appointment();
        assertNull(appointment.getId());
        assertNull(appointment.getPatientId());
    }

    @Test
    void appointmentParameterizedConstructorShouldSetAllFields() {
        Appointment appointment = new Appointment(1, LocalDate.of(2026, 5, 1), LocalTime.of(10, 30), "Checkup", "Dr. Lopez");
        assertEquals(1, appointment.getPatientId());
        assertEquals(LocalDate.of(2026, 5, 1), appointment.getDate());
        assertEquals(LocalTime.of(10, 30), appointment.getTime());
        assertEquals("Checkup", appointment.getReason());
        assertEquals("Dr. Lopez", appointment.getVeterinarian());
    }

    @Test
    void appointmentSettersShouldUpdateFields() {
        Appointment appointment = new Appointment();
        appointment.setId(5);
        appointment.setPatientId(10);
        appointment.setDate(LocalDate.of(2026, 6, 15));
        appointment.setTime(LocalTime.of(14, 0));
        appointment.setReason("Vaccination");
        appointment.setVeterinarian("Dr. Perez");

        assertEquals(5, appointment.getId());
        assertEquals(10, appointment.getPatientId());
        assertEquals(LocalDate.of(2026, 6, 15), appointment.getDate());
        assertEquals(LocalTime.of(14, 0), appointment.getTime());
        assertEquals("Vaccination", appointment.getReason());
        assertEquals("Dr. Perez", appointment.getVeterinarian());
    }

    // ── Patient ──────────────────────────────────────────────────────────────

    @Test
    void patientDefaultConstructorShouldCreateInstance() {
        Patient patient = new Patient();
        assertNull(patient.getId());
        assertNull(patient.getName());
    }

    @Test
    void patientParameterizedConstructorShouldSetAllFields() {
        Patient patient = new Patient("Luna", "Dog", "Labrador", 4, "Ana");
        assertEquals("Luna", patient.getName());
        assertEquals("Dog", patient.getSpecies());
        assertEquals("Labrador", patient.getBreed());
        assertEquals(4, patient.getAge());
        assertEquals("Ana", patient.getOwner());
    }

    @Test
    void patientSettersShouldUpdateFields() {
        Patient patient = new Patient();
        patient.setId(1);
        patient.setName("Rex");
        patient.setSpecies("Cat");
        patient.setBreed("Persian");
        patient.setAge(2);
        patient.setOwner("Carlos");

        assertEquals(1, patient.getId());
        assertEquals("Rex", patient.getName());
        assertEquals("Cat", patient.getSpecies());
        assertEquals("Persian", patient.getBreed());
        assertEquals(2, patient.getAge());
        assertEquals("Carlos", patient.getOwner());
    }

    // ── Pet ──────────────────────────────────────────────────────────────────

    @Test
    void petDefaultConstructorShouldCreateInstance() {
        Pet pet = new Pet();
        assertNull(pet.getId());
        assertNull(pet.getStatus());
    }

    @Test
    void petParameterizedConstructorShouldSetAllFieldsAndDefaultStatus() {
        Pet pet = new Pet("Fido", "Dog", "Labrador", 3, "Male", "Santiago", List.of("url1"));
        assertEquals("Fido", pet.getName());
        assertEquals("Dog", pet.getSpecies());
        assertEquals("Labrador", pet.getBreed());
        assertEquals(3, pet.getAge());
        assertEquals("Male", pet.getGender());
        assertEquals("Santiago", pet.getLocation());
        assertEquals(List.of("url1"), pet.getPhotos());
        assertEquals("available", pet.getStatus());
    }

    @Test
    void petSettersShouldUpdateFields() {
        Pet pet = new Pet();
        pet.setId(1);
        pet.setName("Rex");
        pet.setSpecies("Cat");
        pet.setBreed("Siamese");
        pet.setAge(5);
        pet.setGender("Female");
        pet.setLocation("Valparaiso");
        pet.setPhotos(List.of("url2"));
        pet.setStatus("adopted");

        assertEquals(1, pet.getId());
        assertEquals("Rex", pet.getName());
        assertEquals("Cat", pet.getSpecies());
        assertEquals("Siamese", pet.getBreed());
        assertEquals(5, pet.getAge());
        assertEquals("Female", pet.getGender());
        assertEquals("Valparaiso", pet.getLocation());
        assertEquals(List.of("url2"), pet.getPhotos());
        assertEquals("adopted", pet.getStatus());
    }

    // ── Invoice ──────────────────────────────────────────────────────────────

    @Test
    void invoiceDefaultConstructorShouldCreateInstance() {
        Invoice invoice = new Invoice();
        assertNull(invoice.getId());
        assertNotNull(invoice.getItems());
        assertTrue(invoice.getItems().isEmpty());
    }

    @Test
    void invoiceSettersShouldUpdateFields() {
        Invoice invoice = new Invoice();
        invoice.setId(1);
        invoice.setAppointmentId(10);
        invoice.setIssueDate(LocalDate.of(2026, 5, 1));
        invoice.setVatRate(new BigDecimal("0.19"));
        invoice.setSubtotal(new BigDecimal("10000"));
        invoice.setVatAmount(new BigDecimal("1900"));
        invoice.setTotal(new BigDecimal("11900"));
        invoice.setNotes("Test notes");

        assertEquals(1, invoice.getId());
        assertEquals(10, invoice.getAppointmentId());
        assertEquals(LocalDate.of(2026, 5, 1), invoice.getIssueDate());
        assertEquals(new BigDecimal("0.19"), invoice.getVatRate());
        assertEquals(new BigDecimal("10000"), invoice.getSubtotal());
        assertEquals(new BigDecimal("1900"), invoice.getVatAmount());
        assertEquals(new BigDecimal("11900"), invoice.getTotal());
        assertEquals("Test notes", invoice.getNotes());
    }

    @Test
    void invoiceCalculateTotalsShouldComputeCorrectly() {
        Invoice invoice = new Invoice();
        invoice.setVatRate(new BigDecimal("0.19"));
        InvoiceLineItem item1 = new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Consulta", 1, new BigDecimal("25000"));
        InvoiceLineItem item2 = new InvoiceLineItem(InvoiceLineItemType.MEDICATION, "Antibiotico", 2, new BigDecimal("7500"));
        invoice.getItems().add(item1);
        invoice.getItems().add(item2);

        invoice.calculateTotals();

        assertEquals(new BigDecimal("40000"), invoice.getSubtotal());
        assertEquals(new BigDecimal("7600.00"), invoice.getVatAmount());
        assertEquals(new BigDecimal("47600.00"), invoice.getTotal());
    }

    @Test
    void invoiceCalculateTotalsShouldHandleNullVatRate() {
        Invoice invoice = new Invoice();
        invoice.setVatRate(null);
        InvoiceLineItem item = new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Consulta", 1, new BigDecimal("10000"));
        invoice.getItems().add(item);

        invoice.calculateTotals();

        assertEquals(new BigDecimal("10000"), invoice.getSubtotal());
        assertEquals(new BigDecimal("0"), invoice.getVatAmount());
        assertEquals(new BigDecimal("10000"), invoice.getTotal());
    }

    @Test
    void invoiceSetItemsShouldReplaceList() {
        Invoice invoice = new Invoice();
        List<InvoiceLineItem> items = new ArrayList<>();
        items.add(new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Test", 1, BigDecimal.TEN));
        invoice.setItems(items);
        assertEquals(1, invoice.getItems().size());
    }

    // ── InvoiceLineItem ──────────────────────────────────────────────────────

    @Test
    void invoiceLineItemDefaultConstructorShouldCreateInstance() {
        InvoiceLineItem item = new InvoiceLineItem();
        assertNull(item.getId());
        assertNull(item.getType());
    }

    @Test
    void invoiceLineItemParameterizedConstructorShouldSetFields() {
        InvoiceLineItem item = new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Consulta", 1, new BigDecimal("25000"));
        assertEquals(InvoiceLineItemType.SERVICE, item.getType());
        assertEquals("Consulta", item.getDescription());
        assertEquals(1, item.getQuantity());
        assertEquals(new BigDecimal("25000"), item.getUnitPrice());
    }

    @Test
    void invoiceLineItemRecalculateLineTotalShouldMultiplyQuantityByUnitPrice() {
        InvoiceLineItem item = new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Consulta", 3, new BigDecimal("10000"));
        item.recalculateLineTotal();
        assertEquals(new BigDecimal("30000"), item.getLineTotal());
    }

    @Test
    void invoiceLineItemRecalculateLineTotalShouldHandleNullUnitPrice() {
        InvoiceLineItem item = new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Consulta", 3, null);
        item.recalculateLineTotal();
        assertEquals(BigDecimal.ZERO, item.getLineTotal());
    }

    @Test
    void invoiceLineItemRecalculateLineTotalShouldHandleNullQuantity() {
        InvoiceLineItem item = new InvoiceLineItem(InvoiceLineItemType.SERVICE, "Consulta", null, new BigDecimal("10000"));
        item.recalculateLineTotal();
        assertEquals(new BigDecimal("0"), item.getLineTotal());
    }

    @Test
    void invoiceLineItemSettersShouldUpdateFields() {
        InvoiceLineItem item = new InvoiceLineItem();
        item.setId(1);
        item.setType(InvoiceLineItemType.MEDICATION);
        item.setDescription("Antibiotico");
        item.setQuantity(2);
        item.setUnitPrice(new BigDecimal("5000"));
        item.setLineTotal(new BigDecimal("10000"));
        Invoice invoice = new Invoice();
        item.setInvoice(invoice);

        assertEquals(1, item.getId());
        assertEquals(InvoiceLineItemType.MEDICATION, item.getType());
        assertEquals("Antibiotico", item.getDescription());
        assertEquals(2, item.getQuantity());
        assertEquals(new BigDecimal("5000"), item.getUnitPrice());
        assertEquals(new BigDecimal("10000"), item.getLineTotal());
        assertEquals(invoice, item.getInvoice());
    }

    // ── InvoiceLineItemType ──────────────────────────────────────────────────

    @Test
    void invoiceLineItemTypeShouldHaveThreeValues() {
        assertEquals(3, InvoiceLineItemType.values().length);
    }

    @Test
    void invoiceLineItemTypeValueOfShouldWork() {
        assertEquals(InvoiceLineItemType.SERVICE, InvoiceLineItemType.valueOf("SERVICE"));
        assertEquals(InvoiceLineItemType.MEDICATION, InvoiceLineItemType.valueOf("MEDICATION"));
        assertEquals(InvoiceLineItemType.ADDITIONAL_CHARGE, InvoiceLineItemType.valueOf("ADDITIONAL_CHARGE"));
    }

    // ── User ─────────────────────────────────────────────────────────────────

    @Test
    void userSettersAndGettersShouldWork() {
        User user = new User();
        user.setId(1);
        user.setUsername("admin");
        user.setEmail("admin@test.com");
        user.setPassword("secret");

        assertEquals(1, user.getId());
        assertEquals("admin", user.getUsername());
        assertEquals("admin@test.com", user.getEmail());
        assertEquals("secret", user.getPassword());
    }

    @Test
    void userShouldImplementUserDetailsCorrectly() {
        User user = new User();
        assertTrue(user.isAccountNonExpired());
        assertTrue(user.isAccountNonLocked());
        assertTrue(user.isCredentialsNonExpired());
        assertTrue(user.isEnabled());
        assertNotNull(user.getAuthorities());
        assertTrue(user.getAuthorities().isEmpty());
    }

    // ── LoginRequest ─────────────────────────────────────────────────────────

    @Test
    void loginRequestDefaultConstructorShouldWork() {
        LoginRequest request = new LoginRequest();
        assertNull(request.getUsername());
        assertNull(request.getPassword());
    }

    @Test
    void loginRequestParameterizedConstructorShouldWork() {
        LoginRequest request = new LoginRequest("admin", "secret");
        assertEquals("admin", request.getUsername());
        assertEquals("secret", request.getPassword());
    }

    @Test
    void loginRequestSettersShouldWork() {
        LoginRequest request = new LoginRequest();
        request.setUsername("admin");
        request.setPassword("secret");
        assertEquals("admin", request.getUsername());
        assertEquals("secret", request.getPassword());
    }

    // ── UserRegistrationRequest ──────────────────────────────────────────────

    @Test
    void userRegistrationRequestSettersAndGettersShouldWork() {
        UserRegistrationRequest request = new UserRegistrationRequest();
        request.setUsername("newuser");
        request.setEmail("new@test.com");
        request.setPassword("pass123");

        assertEquals("newuser", request.getUsername());
        assertEquals("new@test.com", request.getEmail());
        assertEquals("pass123", request.getPassword());
    }

    // ── UserResponse ─────────────────────────────────────────────────────────

    @Test
    void userResponseConstructorShouldSetFields() {
        UserResponse response = new UserResponse(1, "admin", "admin@test.com");
        assertEquals(1, response.getId());
        assertEquals("admin", response.getUsername());
        assertEquals("admin@test.com", response.getEmail());
    }

    // ── Constants ────────────────────────────────────────────────────────────

    @Test
    void getSigningKeyShouldReturnKeyFromPlainString() {
        assertNotNull(Constants.getSigningKey(Constants.SUPER_SECRET_KEY));
    }

    @Test
    void getSigningKeyB64ShouldReturnKeyFromBase64() {
        assertNotNull(Constants.getSigningKeyB64(Constants.SUPER_SECRET_KEY));
    }

    @Test
    void constantsShouldHaveExpectedValues() {
        assertEquals("/login", Constants.LOGIN_URL);
        assertEquals("Authorization", Constants.HEADER_AUTHORIZACION_KEY);
        assertEquals("Bearer ", Constants.TOKEN_BEARER_PREFIX);
    }

    // ── SecuredController ────────────────────────────────────────────────────

    @Test
    void greetingsShouldReturnFormattedMessage() {
        SecuredController controller = new SecuredController();
        assertEquals("Hello {World}", controller.greetings("World"));
    }

    @Test
    void greetingsShouldUseProvidedName() {
        SecuredController controller = new SecuredController();
        assertEquals("Hello {Carlos}", controller.greetings("Carlos"));
    }
}