package com.duoc.backend;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AppointmentControllerTest {

    @Mock
    private AppointmentRepository appointmentRepository;

    @Mock
    private PatientRepository patientRepository;

    @InjectMocks
    private AppointmentController appointmentController;

    private Appointment appointment;

    @BeforeEach
    void setUp() {
        appointment = new Appointment(1, LocalDate.of(2026, 5, 1), LocalTime.of(10, 0), "Checkup", "Dr. Lopez");
        appointment.setId(1);
    }

    // ── createAppointment ────────────────────────────────────────────────────

    @Test
    void createAppointmentShouldReturnCreatedWhenValid() {
        when(patientRepository.existsById(1)).thenReturn(true);

        ResponseEntity<?> response = appointmentController.createAppointment(appointment);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(appointment, response.getBody());
        verify(appointmentRepository).save(appointment);
    }

    @Test
    void createAppointmentShouldReturnBadRequestWhenPatientIdNull() {
        Appointment noPatient = new Appointment(null, LocalDate.now(), LocalTime.now(), "Checkup", "Dr. Lopez");

        ResponseEntity<?> response = appointmentController.createAppointment(noPatient);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Patient not found for patientId: null", response.getBody());
        verify(appointmentRepository, never()).save(any());
    }

    @Test
    void createAppointmentShouldReturnBadRequestWhenPatientNotFound() {
        when(patientRepository.existsById(99)).thenReturn(false);
        Appointment appt = new Appointment(99, LocalDate.now(), LocalTime.now(), "Checkup", "Dr. Lopez");

        ResponseEntity<?> response = appointmentController.createAppointment(appt);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Patient not found for patientId: 99", response.getBody());
        verify(appointmentRepository, never()).save(any());
    }

    @Test
    void createAppointmentShouldReturnBadRequestWhenRepositoryThrows() {
        when(patientRepository.existsById(1)).thenReturn(true);
        doThrow(new RuntimeException("DB down")).when(appointmentRepository).save(any());

        ResponseEntity<?> response = appointmentController.createAppointment(appointment);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertInstanceOf(Map.class, response.getBody());
        @SuppressWarnings("unchecked")
        Map<String, String> error = (Map<String, String>) response.getBody();
        assertEquals("Error al registrar: DB down", error.get("message"));
    }

    // ── getAllAppointments ────────────────────────────────────────────────────

    @Test
    void getAllAppointmentsShouldReturnOkWithAppointments() {
        List<Appointment> appointments = List.of(appointment);
        when(appointmentRepository.findAll()).thenReturn(appointments);

        ResponseEntity<Iterable<Appointment>> response = appointmentController.getAllAppointments();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(appointments, response.getBody());
    }

    @Test
    void getAllAppointmentsShouldReturnInternalServerErrorWhenRepositoryFails() {
        when(appointmentRepository.findAll()).thenThrow(new RuntimeException("DB down"));

        ResponseEntity<Iterable<Appointment>> response = appointmentController.getAllAppointments();

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());
    }

    // ── getAppointmentById ───────────────────────────────────────────────────

    @Test
    void getAppointmentByIdShouldReturnOkWhenFound() {
        when(appointmentRepository.findById(1)).thenReturn(Optional.of(appointment));

        ResponseEntity<Appointment> response = appointmentController.getAppointmentById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(appointment, response.getBody());
    }

    @Test
    void getAppointmentByIdShouldReturnNotFoundWhenMissing() {
        when(appointmentRepository.findById(99)).thenReturn(Optional.empty());

        ResponseEntity<Appointment> response = appointmentController.getAppointmentById(99);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    void getAppointmentByIdShouldReturnInternalServerErrorWhenRepositoryFails() {
        when(appointmentRepository.findById(1)).thenThrow(new RuntimeException("DB down"));

        ResponseEntity<Appointment> response = appointmentController.getAppointmentById(1);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNull(response.getBody());
    }

    // ── getAppointmentsForPatient ────────────────────────────────────────────

    @Test
    void getAppointmentsForPatientShouldReturnOkWhenPatientExists() {
        when(patientRepository.existsById(1)).thenReturn(true);
        when(appointmentRepository.findByPatientId(1)).thenReturn(List.of(appointment));

        ResponseEntity<List<Appointment>> response = appointmentController.getAppointmentsForPatient(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
    }

    @Test
    void getAppointmentsForPatientShouldReturnNotFoundWhenPatientMissing() {
        when(patientRepository.existsById(99)).thenReturn(false);

        ResponseEntity<List<Appointment>> response = appointmentController.getAppointmentsForPatient(99);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void getAppointmentsForPatientShouldReturnInternalServerErrorWhenRepositoryFails() {
        when(patientRepository.existsById(1)).thenReturn(true);
        when(appointmentRepository.findByPatientId(1)).thenThrow(new RuntimeException("DB down"));

        ResponseEntity<List<Appointment>> response = appointmentController.getAppointmentsForPatient(1);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    // ── updateAppointment ────────────────────────────────────────────────────

    @Test
    void updateAppointmentShouldReturnOkWhenValid() {
        when(appointmentRepository.existsById(1)).thenReturn(true);
        when(patientRepository.existsById(1)).thenReturn(true);

        ResponseEntity<String> response = appointmentController.updateAppointment(1, appointment);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Appointment updated successfully", response.getBody());
        verify(appointmentRepository).save(appointment);
    }

    @Test
    void updateAppointmentShouldReturnNotFoundWhenAppointmentMissing() {
        when(appointmentRepository.existsById(99)).thenReturn(false);

        ResponseEntity<String> response = appointmentController.updateAppointment(99, appointment);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void updateAppointmentShouldReturnBadRequestWhenPatientNotFound() {
        when(appointmentRepository.existsById(1)).thenReturn(true);
        when(patientRepository.existsById(1)).thenReturn(false);

        ResponseEntity<String> response = appointmentController.updateAppointment(1, appointment);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Patient not found for patientId: 1", response.getBody());
    }

    @Test
    void updateAppointmentShouldReturnBadRequestWhenPatientIdNull() {
        Appointment noPatient = new Appointment(null, LocalDate.now(), LocalTime.now(), "Checkup", "Dr. Lopez");
        when(appointmentRepository.existsById(1)).thenReturn(true);

        ResponseEntity<String> response = appointmentController.updateAppointment(1, noPatient);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void updateAppointmentShouldReturnBadRequestWhenRepositoryThrows() {
        when(appointmentRepository.existsById(1)).thenReturn(true);
        when(patientRepository.existsById(1)).thenReturn(true);
        doThrow(new RuntimeException("DB down")).when(appointmentRepository).save(any());

        ResponseEntity<String> response = appointmentController.updateAppointment(1, appointment);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    // ── deleteAppointment ────────────────────────────────────────────────────

    @Test
    void deleteAppointmentShouldReturnOkWhenFound() {
        when(appointmentRepository.existsById(1)).thenReturn(true);

        ResponseEntity<String> response = appointmentController.deleteAppointment(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Appointment deleted successfully", response.getBody());
        verify(appointmentRepository).deleteById(1);
    }

    @Test
    void deleteAppointmentShouldReturnNotFoundWhenMissing() {
        when(appointmentRepository.existsById(99)).thenReturn(false);

        ResponseEntity<String> response = appointmentController.deleteAppointment(99);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void deleteAppointmentShouldReturnInternalServerErrorWhenRepositoryFails() {
        when(appointmentRepository.existsById(1)).thenReturn(true);
        doThrow(new RuntimeException("DB down")).when(appointmentRepository).deleteById(1);

        ResponseEntity<String> response = appointmentController.deleteAppointment(1);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }
}