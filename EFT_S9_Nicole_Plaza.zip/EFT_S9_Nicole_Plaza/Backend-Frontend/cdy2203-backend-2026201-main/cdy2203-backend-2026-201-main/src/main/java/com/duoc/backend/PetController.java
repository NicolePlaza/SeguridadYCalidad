package com.duoc.backend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
public class PetController {

    @Autowired
    private PetRepository petRepository;

    private static final String MESSAGE_KEY = "message";

    @PostMapping("/pets")
    public ResponseEntity<Object> createPet(@RequestBody Pet pet) {
        try {
            petRepository.save(pet);
            return ResponseEntity.status(HttpStatus.CREATED).body(pet);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put(MESSAGE_KEY, "Error al registrar mascota: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/pets")
    public ResponseEntity<Iterable<Pet>> getAllPets() {
        try {
            Iterable<Pet> pets = petRepository.findAll();
            return ResponseEntity.ok(pets);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/pets/available")
    public ResponseEntity<List<Pet>> getAvailablePets() {
        try {
            List<Pet> pets = petRepository.findByStatus("available");
            return ResponseEntity.ok(pets);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/pets/{id}")
    public ResponseEntity<Pet> getPetById(@PathVariable Integer id) {
        try {
            Optional<Pet> pet = petRepository.findById(id);
            if (pet.isPresent()) {
                return ResponseEntity.ok(pet.get());
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @PutMapping("/pets/{id}")
    public ResponseEntity<Object> updatePet(@PathVariable Integer id, @RequestBody Pet petDetails) {
        try {
            Optional<Pet> pet = petRepository.findById(id);
            if (pet.isPresent()) {
                Pet existingPet = pet.get();
                updatePetDetails(existingPet, petDetails);
                petRepository.save(existingPet);
                return ResponseEntity.ok(existingPet);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put(MESSAGE_KEY, "Error al actualizar mascota: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    private void updatePetDetails(Pet existingPet, Pet petDetails) {
        if (petDetails.getName() != null) {
            existingPet.setName(petDetails.getName());
        }
        if (petDetails.getSpecies() != null) {
            existingPet.setSpecies(petDetails.getSpecies());
        }
        if (petDetails.getBreed() != null) {
            existingPet.setBreed(petDetails.getBreed());
        }
        if (petDetails.getAge() != null) {
            existingPet.setAge(petDetails.getAge());
        }
        if (petDetails.getGender() != null) {
            existingPet.setGender(petDetails.getGender());
        }
        if (petDetails.getLocation() != null) {
            existingPet.setLocation(petDetails.getLocation());
        }
        if (petDetails.getPhotos() != null) {
            existingPet.setPhotos(petDetails.getPhotos());
        }
        if (petDetails.getStatus() != null) {
            existingPet.setStatus(petDetails.getStatus());
        }
    }

    @DeleteMapping("/pets/{id}")
    public ResponseEntity<Object> deletePet(@PathVariable Integer id) {
        try {
            Optional<Pet> pet = petRepository.findById(id);
            if (pet.isPresent()) {
                petRepository.deleteById(id);
                Map<String, String> response = new HashMap<>();
                response.put(MESSAGE_KEY, "Mascota eliminada exitosamente");
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put(MESSAGE_KEY, "Error al eliminar mascota: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/pets/search")
    public ResponseEntity<List<Pet>> searchPets(
            @RequestParam(required = false) String species,
            @RequestParam(required = false) String gender,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) Integer age,
            @RequestParam(defaultValue = "available") String status) {
        try {
            List<Pet> pets = new java.util.ArrayList<>(petRepository.findByStatus(status));
            pets.removeIf(p -> species != null && !species.equals(p.getSpecies()));
            pets.removeIf(p -> gender != null && !gender.equals(p.getGender()));
            pets.removeIf(p -> location != null && !location.equals(p.getLocation()));
            pets.removeIf(p -> age != null && !age.equals(p.getAge()));
            return ResponseEntity.ok(pets);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
