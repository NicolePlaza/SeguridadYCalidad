package com.duoc.seguridadcalidad;

import jakarta.servlet.http.Cookie;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseCookie;
import org.springframework.mock.web.MockHttpServletRequest;

import static org.junit.jupiter.api.Assertions.*;

class JwtCookieServiceTests {

    private final JwtCookieService service = new JwtCookieService(true, 3600, "Strict");

    @Test
    void createAuthCookieShouldReturnCookieWithToken() {
        ResponseCookie cookie = service.createAuthCookie("my-token");

        assertEquals("AUTH_TOKEN", cookie.getName());
        assertEquals("my-token", cookie.getValue());
        assertTrue(cookie.isHttpOnly());
        assertTrue(cookie.isSecure());
        assertEquals("Strict", cookie.getSameSite());
        assertEquals("/", cookie.getPath());
        assertEquals(3600, cookie.getMaxAge().getSeconds());
    }

    @Test
    void clearAuthCookieShouldReturnCookieWithZeroMaxAge() {
        ResponseCookie cookie = service.clearAuthCookie();

        assertEquals("AUTH_TOKEN", cookie.getName());
        assertEquals("", cookie.getValue());
        assertEquals(0, cookie.getMaxAge().getSeconds());
    }

    @Test
    void extractTokenShouldReturnTokenFromAuthorizationHeader() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer my-token");

        String token = service.extractToken(request);

        assertEquals("my-token", token);
    }

    @Test
    void extractTokenShouldReturnTokenFromCookieWhenNoHeader() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setCookies(new Cookie("AUTH_TOKEN", "cookie-token"));

        String token = service.extractToken(request);

        assertEquals("cookie-token", token);
    }

    @Test
    void extractTokenShouldReturnNullWhenNoCookiesOrHeader() {
        MockHttpServletRequest request = new MockHttpServletRequest();

        String token = service.extractToken(request);

        assertNull(token);
    }

    @Test
    void extractTokenShouldReturnNullWhenCookieValueIsBlank() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setCookies(new Cookie("AUTH_TOKEN", "  "));

        String token = service.extractToken(request);

        assertNull(token);
    }

    @Test
    void extractTokenShouldIgnoreNonAuthCookies() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setCookies(new Cookie("OTHER_COOKIE", "some-value"));

        String token = service.extractToken(request);

        assertNull(token);
    }

    @Test
    void extractTokenShouldPreferHeaderOverCookie() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer header-token");
        request.setCookies(new Cookie("AUTH_TOKEN", "cookie-token"));

        String token = service.extractToken(request);

        assertEquals("header-token", token);
    }
}