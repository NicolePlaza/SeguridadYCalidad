package com.duoc.seguridadcalidad;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RestControllerTests {

    @Mock
    private BackendService backendService;

    @Mock
    private JwtCookieService jwtCookieService;

    private AppointmentRestController appointmentRestController;
    private PatientRestController patientRestController;
    private PetRestController petRestController;

    @BeforeEach
    void setUp() {
        appointmentRestController = new AppointmentRestController(backendService, jwtCookieService);
        patientRestController = new PatientRestController(backendService, jwtCookieService);
        petRestController = new PetRestController(backendService, jwtCookieService);
    }

    // ── AppointmentRestController ────────────────────────────────────────────

    @Test
    void getAppointmentsShouldReturnOkWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.getAppointments("valid-token")).thenReturn(List.of(Map.of("id", 1)));

        ResponseEntity<List<Map<String, Object>>> response = appointmentRestController.getAll(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
    }

    @Test
    void getAppointmentsShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<List<Map<String, Object>>> response = appointmentRestController.getAll(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void createAppointmentShouldReturnOkWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        Map<String, Object> appointment = Map.of("date", "2026-05-01");
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.createAppointment("valid-token", appointment)).thenReturn(Map.of("id", 1));

        ResponseEntity<Map<String, Object>> response = appointmentRestController.create(request, appointment);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().get("id"));
    }

    @Test
    void createAppointmentShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<Map<String, Object>> response = appointmentRestController.create(request, Map.of());

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    // ── PatientRestController ────────────────────────────────────────────────

    @Test
    void getPatientsShouldReturnOkWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.getPatients("valid-token")).thenReturn(List.of(Map.of("id", 1, "name", "Rex")));

        ResponseEntity<List<Map<String, Object>>> response = patientRestController.getAll(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
    }

    @Test
    void getPatientsShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<List<Map<String, Object>>> response = patientRestController.getAll(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void createPatientShouldReturnOkWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        Map<String, Object> patient = Map.of("name", "Rex");
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.createPatient("valid-token", patient)).thenReturn(Map.of("id", 1));

        ResponseEntity<Map<String, Object>> response = patientRestController.create(request, patient);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void createPatientShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<Map<String, Object>> response = patientRestController.create(request, Map.of());

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    // ── PetRestController ────────────────────────────────────────────────────

    @Test
    void getAllPetsShouldReturnOk() {
        when(backendService.getPets()).thenReturn(List.of(Map.of("id", 1, "name", "Fido")));

        ResponseEntity<List<Map<String, Object>>> response = petRestController.getAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
    }

    @Test
    void getAvailablePetsShouldReturnOk() {
        when(backendService.getAvailablePets()).thenReturn(List.of(Map.of("id", 1)));

        ResponseEntity<List<Map<String, Object>>> response = petRestController.getAvailable();

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void searchPetsShouldReturnOk() {
        when(backendService.searchPets("Dog", null, null, null, null)).thenReturn(List.of(Map.of("id", 1)));

        ResponseEntity<List<Map<String, Object>>> response = petRestController.search("Dog", null, null, null, null);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void createPetShouldReturnCreatedWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        Map<String, Object> pet = Map.of("name", "Buddy");
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.createPet("valid-token", pet)).thenReturn(Map.of("id", 1));

        ResponseEntity<Map<String, Object>> response = petRestController.create(request, pet);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    void createPetShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<Map<String, Object>> response = petRestController.create(request, Map.of());

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void updatePetShouldReturnOkWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        Map<String, Object> pet = Map.of("name", "Rex Updated");
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.updatePet("valid-token", 1, pet)).thenReturn(Map.of("id", 1));

        ResponseEntity<Map<String, Object>> response = petRestController.update(1, request, pet);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void updatePetShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<Map<String, Object>> response = petRestController.update(1, request, Map.of());

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void deletePetShouldReturnOkWhenAuthenticated() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");
        when(backendService.deletePet("valid-token", 1)).thenReturn(Map.of("message", "deleted"));

        ResponseEntity<Map<String, Object>> response = petRestController.delete(1, request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void deletePetShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<Map<String, Object>> response = petRestController.delete(1, request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }
}