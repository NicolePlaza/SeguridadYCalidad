package com.duoc.seguridadcalidad;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuthControllerTests {

    @Mock
    private BackendService backendService;

    @Mock
    private JwtCookieService jwtCookieService;

    private AuthController authController;

    @BeforeEach
    void setUp() {
        authController = new AuthController(backendService, jwtCookieService);
    }

    @Test
    void loginShouldReturnNoContentWithCookieWhenValid() {
        AuthRequest request = new AuthRequest();
        request.setUsername("user");
        request.setPassword("pass");

        when(backendService.login(any())).thenReturn(new AuthResponse("test-token"));
        when(jwtCookieService.createAuthCookie("test-token"))
                .thenReturn(org.springframework.http.ResponseCookie.from("AUTH_TOKEN", "test-token").build());

        ResponseEntity<?> response = authController.createAuthenticationToken(request);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertFalse(response.getHeaders().get("Set-Cookie").isEmpty());
    }

    @Test
    void loginShouldReturnBackendErrorStatusWhenCredentialsInvalid() {
        AuthRequest request = new AuthRequest();
        request.setUsername("user");
        request.setPassword("wrong");

        when(backendService.login(any())).thenThrow(
                HttpClientErrorException.create(HttpStatus.UNAUTHORIZED, "Unauthorized", null, null, null));

        ResponseEntity<?> response = authController.createAuthenticationToken(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void loginShouldReturnServiceUnavailableWhenBackendDown() {
        AuthRequest request = new AuthRequest();
        when(backendService.login(any())).thenThrow(new ResourceAccessException("Connection refused"));

        ResponseEntity<?> response = authController.createAuthenticationToken(request);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
    }

    @Test
    void loginShouldReturnInternalServerErrorOnUnexpectedException() {
        AuthRequest request = new AuthRequest();
        when(backendService.login(any())).thenThrow(new RuntimeException("Unexpected"));

        ResponseEntity<?> response = authController.createAuthenticationToken(request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    void logoutShouldReturnNoContentWithClearCookie() {
        when(jwtCookieService.clearAuthCookie())
                .thenReturn(org.springframework.http.ResponseCookie.from("AUTH_TOKEN", "").maxAge(0).build());

        ResponseEntity<Void> response = authController.logout();

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertNotNull(response.getHeaders().getFirst("Set-Cookie"));
    }

    @Test
    void sessionShouldReturnNoContentWhenTokenPresent() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn("valid-token");

        ResponseEntity<Void> response = authController.session(request);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }

    @Test
    void sessionShouldReturnUnauthorizedWhenNoToken() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        when(jwtCookieService.extractToken(request)).thenReturn(null);

        ResponseEntity<Void> response = authController.session(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }
}