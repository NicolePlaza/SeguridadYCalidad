package com.duoc.seguridadcalidad;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FrontendModelTests {

    // ── Patient ──────────────────────────────────────────────────────────────

    @Test
    void patientDefaultConstructorShouldWork() {
        Patient patient = new Patient();
        assertNull(patient.getId());
        assertNull(patient.getName());
    }

    @Test
    void patientFullConstructorShouldWork() {
        Patient patient = new Patient(1L, "Rex", "Dog", "Labrador", 4, "Ana");
        assertEquals(1L, patient.getId());
        assertEquals("Rex", patient.getName());
        assertEquals("Dog", patient.getSpecies());
        assertEquals("Labrador", patient.getBreed());
        assertEquals(4, patient.getAge());
        assertEquals("Ana", patient.getOwner());
    }

    @Test
    void patientSettersShouldWork() {
        Patient patient = new Patient();
        patient.setId(2L);
        patient.setName("Luna");
        patient.setSpecies("Cat");
        patient.setBreed("Siamese");
        patient.setAge(3);
        patient.setOwner("Carlos");

        assertEquals(2L, patient.getId());
        assertEquals("Luna", patient.getName());
        assertEquals("Cat", patient.getSpecies());
        assertEquals("Siamese", patient.getBreed());
        assertEquals(3, patient.getAge());
        assertEquals("Carlos", patient.getOwner());
    }

    // ── Appointment ──────────────────────────────────────────────────────────

    @Test
    void appointmentDefaultConstructorShouldWork() {
        Appointment appointment = new Appointment();
        assertNull(appointment.getId());
    }

    @Test
    void appointmentFullConstructorShouldWork() {
        Appointment appointment = new Appointment(1L, 10L, LocalDate.of(2026, 5, 1), LocalTime.of(10, 0), "Checkup", "Dr. Lopez");
        assertEquals(1L, appointment.getId());
        assertEquals(10L, appointment.getPatientId());
        assertEquals(LocalDate.of(2026, 5, 1), appointment.getDate());
        assertEquals(LocalTime.of(10, 0), appointment.getTime());
        assertEquals("Checkup", appointment.getReason());
        assertEquals("Dr. Lopez", appointment.getVeterinarian());
    }

    @Test
    void appointmentSettersShouldWork() {
        Appointment appointment = new Appointment();
        appointment.setId(5L);
        appointment.setPatientId(20L);
        appointment.setDate(LocalDate.of(2026, 6, 15));
        appointment.setTime(LocalTime.of(14, 30));
        appointment.setReason("Surgery");
        appointment.setVeterinarian("Dr. Perez");

        assertEquals(5L, appointment.getId());
        assertEquals(20L, appointment.getPatientId());
        assertEquals(LocalDate.of(2026, 6, 15), appointment.getDate());
        assertEquals(LocalTime.of(14, 30), appointment.getTime());
        assertEquals("Surgery", appointment.getReason());
        assertEquals("Dr. Perez", appointment.getVeterinarian());
    }

    // ── AppointmentRepository ────────────────────────────────────────────────

    @Test
    void appointmentRepositoryFindAllShouldReturnEmptyListInitially() {
        AppointmentRepository repo = new AppointmentRepository();
        assertTrue(repo.findAll().isEmpty());
    }

    @Test
    void appointmentRepositorySaveShouldAssignId() {
        AppointmentRepository repo = new AppointmentRepository();
        Appointment saved = repo.save(new Appointment());
        assertNotNull(saved.getId());
    }

    @Test
    void appointmentRepositorySaveShouldNotOverwriteExistingId() {
        AppointmentRepository repo = new AppointmentRepository();
        Appointment appointment = new Appointment();
        appointment.setId(99L);
        Appointment saved = repo.save(appointment);
        assertEquals(99L, saved.getId());
    }

    @Test
    void appointmentRepositoryFindAllShouldReturnSavedAppointments() {
        AppointmentRepository repo = new AppointmentRepository();
        repo.save(new Appointment());
        repo.save(new Appointment());
        assertEquals(2, repo.findAll().size());
    }

    @Test
    void appointmentRepositoryFindAllShouldReturnDefensiveCopy() {
        AppointmentRepository repo = new AppointmentRepository();
        repo.save(new Appointment());
        List<Appointment> first = repo.findAll();
        List<Appointment> second = repo.findAll();
        assertNotSame(first, second);
    }

    // ── AuthRequest ──────────────────────────────────────────────────────────

    @Test
    void authRequestSettersAndGettersShouldWork() {
        AuthRequest request = new AuthRequest();
        request.setUsername("user");
        request.setPassword("pass");
        assertEquals("user", request.getUsername());
        assertEquals("pass", request.getPassword());
    }

    // ── AuthResponse ─────────────────────────────────────────────────────────

    @Test
    void authResponseShouldReturnToken() {
        AuthResponse response = new AuthResponse("my-token");
        assertEquals("my-token", response.getToken());
    }

    // ── Invoice ──────────────────────────────────────────────────────────────

    @Test
    void invoiceDefaultConstructorShouldWork() {
        Invoice invoice = new Invoice();
        assertNull(invoice.getId());
        assertNotNull(invoice.getItems());
    }

    @Test
    void invoiceFullConstructorShouldWork() {
        List<InvoiceLineItem> items = new ArrayList<>();
        Invoice invoice = new Invoice(1L, 10L, LocalDate.of(2026, 5, 1), new BigDecimal("0.19"),
                new BigDecimal("10000"), new BigDecimal("1900"), new BigDecimal("11900"), "Notes", items);
        assertEquals(1L, invoice.getId());
        assertEquals(10L, invoice.getAppointmentId());
        assertEquals(new BigDecimal("0.19"), invoice.getVatRate());
        assertEquals("Notes", invoice.getNotes());
    }

    @Test
    void invoiceSettersShouldWork() {
        Invoice invoice = new Invoice();
        invoice.setId(1L);
        invoice.setAppointmentId(10L);
        invoice.setIssueDate(LocalDate.now());
        invoice.setVatRate(new BigDecimal("0.19"));
        invoice.setSubtotal(new BigDecimal("10000"));
        invoice.setVatAmount(new BigDecimal("1900"));
        invoice.setTotal(new BigDecimal("11900"));
        invoice.setNotes("Test");
        invoice.setItems(new ArrayList<>());

        assertEquals(1L, invoice.getId());
        assertEquals(10L, invoice.getAppointmentId());
    }

    // ── InvoiceLineItem ──────────────────────────────────────────────────────

    @Test
    void invoiceLineItemDefaultConstructorShouldWork() {
        InvoiceLineItem item = new InvoiceLineItem();
        assertNull(item.getId());
    }

    @Test
    void invoiceLineItemFullConstructorShouldWork() {
        InvoiceLineItem item = new InvoiceLineItem(1L, InvoiceLineItemType.SERVICE, "Consulta", 1, new BigDecimal("25000"), new BigDecimal("25000"));
        assertEquals(1L, item.getId());
        assertEquals(InvoiceLineItemType.SERVICE, item.getType());
        assertEquals("Consulta", item.getDescription());
        assertEquals(1, item.getQuantity());
        assertEquals(new BigDecimal("25000"), item.getUnitPrice());
        assertEquals(new BigDecimal("25000"), item.getLineTotal());
    }

    @Test
    void invoiceLineItemSettersShouldWork() {
        InvoiceLineItem item = new InvoiceLineItem();
        item.setId(2L);
        item.setType(InvoiceLineItemType.MEDICATION);
        item.setDescription("Antibiotico");
        item.setQuantity(3);
        item.setUnitPrice(new BigDecimal("5000"));
        item.setLineTotal(new BigDecimal("15000"));

        assertEquals(2L, item.getId());
        assertEquals(InvoiceLineItemType.MEDICATION, item.getType());
        assertEquals("Antibiotico", item.getDescription());
        assertEquals(3, item.getQuantity());
    }

    // ── InvoiceCreateRequest ─────────────────────────────────────────────────

    @Test
    void invoiceCreateRequestSettersShouldWork() {
        InvoiceCreateRequest request = new InvoiceCreateRequest();
        request.setIssueDate(LocalDate.of(2026, 5, 1));
        request.setVatRate(new BigDecimal("0.19"));
        request.setNotes("Test");
        request.setItems(new ArrayList<>());

        assertEquals(LocalDate.of(2026, 5, 1), request.getIssueDate());
        assertEquals(new BigDecimal("0.19"), request.getVatRate());
        assertEquals("Test", request.getNotes());
        assertNotNull(request.getItems());
    }
}