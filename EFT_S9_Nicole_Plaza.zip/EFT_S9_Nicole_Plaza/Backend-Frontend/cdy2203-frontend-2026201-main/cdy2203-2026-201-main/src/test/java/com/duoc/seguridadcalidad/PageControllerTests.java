package com.duoc.seguridadcalidad;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PageControllerTests {

    // ── LoginController ──────────────────────────────────────────────────────

    @Test
    void loginShouldReturnLoginView() {
        LoginController controller = new LoginController();
        assertEquals("login", controller.login());
    }

    // ── PatientController ────────────────────────────────────────────────────

    @Test
    void listPatientsShouldReturnPatientsView() {
        PatientController controller = new PatientController();
        assertEquals("patients", controller.listPatients());
    }

    @Test
    void showCreatePatientFormShouldReturnNewPatientView() {
        PatientController controller = new PatientController();
        assertEquals("new_patient", controller.showCreateForm());
    }

    @Test
    void savePatientShouldRedirectToPatients() {
        PatientController controller = new PatientController();
        assertEquals("redirect:/patients", controller.savePatient());
    }

    // ── AppointmentController ────────────────────────────────────────────────

    @Test
    void listAppointmentsShouldReturnAppointmentsView() {
        AppointmentController controller = new AppointmentController();
        assertEquals("appointments", controller.listAppointments());
    }

    @Test
    void showCreateAppointmentFormShouldReturnNewAppointmentView() {
        AppointmentController controller = new AppointmentController();
        assertEquals("new_appointment", controller.showCreateForm());
    }

    @Test
    void saveAppointmentShouldRedirectToAppointments() {
        AppointmentController controller = new AppointmentController();
        assertEquals("redirect:/appointments", controller.saveAppointment());
    }

    // ── InvoicePageController ────────────────────────────────────────────────

    @Test
    void listInvoicesShouldReturnInvoicesView() {
        InvoicePageController controller = new InvoicePageController();
        assertEquals("invoices", controller.listInvoices());
    }

    @Test
    void showCreateInvoiceFormShouldReturnNewInvoiceView() {
        InvoicePageController controller = new InvoicePageController();
        assertEquals("new_invoice", controller.showCreateForm());
    }

    @Test
    void showInvoiceDetailShouldReturnInvoiceDetailView() {
        InvoicePageController controller = new InvoicePageController();
        assertEquals("invoice_detail", controller.showInvoiceDetail(1L));
    }
}